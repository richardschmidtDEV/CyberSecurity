##### Other Application Attacks

##### 1. Clickjacking

- Clickjacking, also known as UI redress attack, is a technique that tricks users into clicking on malicious elements hidden behind legitimate buttons or links on a website.
- Attackers use iframes or CSS to overlay hidden content on top of trusted website elements, leading users to unknowingly perform unintended actions.

##### 2. Remote File Inclusion (RFI) and Local File Inclusion (LFI)

- File Inclusion Attacks involve exploiting vulnerabilities in web applications that dynamically include files.
- RFI allows an attacker to include and execute remote files from external sources, potentially leading to code execution.
- LFI involves accessing files on the server directly, potentially revealing sensitive information.

##### 3. XML External Entity (XXE) Injection

- XXE injection is an attack against XML parsers that exploit insecure processing of external entities.
- Attackers can use XXE to read files from the server, perform SSRF attacks, or cause denial-of-service (DoS) by exploiting vulnerable XML parsing.

##### 4. Server-Side Request Forgery (SSRF)

- SSRF is an attack that manipulates a web application to make unintended HTTP requests to internal or external systems.
- Attackers can exploit SSRF to access internal resources, bypass firewalls, or perform port scanning on internal networks.

##### 5. Command Injection

- Command Injection attacks occur when an attacker manipulates input to execute arbitrary system commands on the server.
- Poorly sanitized user input passed to shell commands can lead to command execution vulnerabilities.

##### 6. Security Misconfigurations

- Misconfigurations, such as default credentials, exposed sensitive information, or unnecessary open ports, can lead to serious security issues.
- Attackers exploit these misconfigurations to gain unauthorized access to systems.

##### 7. Cross-Site Request Forgery (CSRF)

- CSRF attacks trick authenticated users into unknowingly executing malicious actions on websites where they are logged in.
- By forging requests, attackers can perform unauthorized actions on behalf of the victim.

##### 8. Business Logic Vulnerabilities

- Business logic vulnerabilities are flaws in the application's logic that allow attackers to manipulate workflows for malicious purposes.
- Examples include manipulating payment processes or abusing discounts and promotions.

##### 9. Insufficient Session Expiration and Session Fixation

- Attacks involving session expiration or fixation occur when session tokens are not managed properly.
- Attackers may hijack active sessions or trick users into using fixed session IDs to gain unauthorized access.

##### 10. Cross-Site Script Inclusion (XSSI)

- XSSI attacks abuse misconfigured JSON endpoints to expose sensitive data, usually protected by the Same-Origin Policy.