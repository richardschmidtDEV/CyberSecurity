##### Rogue Access Points

##### 1. Introduction

- Rogue access points are unauthorized wireless access points that are installed on a network without the network administrator's knowledge or approval.

##### 2. How Rogue Access Points Work

- Unauthorized Installation: Attackers set up rogue access points in physical proximity to an organization's network to attract users.
- Mimicking Legitimate Networks: Rogue access points often mimic the SSID (network name) of a legitimate network to deceive users into connecting.

##### 3. Risks and Consequences

- Man-in-the-Middle Attacks: Attackers can intercept and manipulate data transmitted through the rogue access point.
- Credential Harvesting: Users who connect to rogue access points might unknowingly provide their login credentials, exposing them to identity theft.

##### 4. Detection and Prevention

- Wireless Site Surveys: Regular site surveys help identify unauthorized access points on the network.
- Wireless Intrusion Detection Systems (WIDS): WIDS can detect and alert administrators about rogue access points.

##### Evil Twins

##### 1. Introduction

- Evil twins are a specific type of rogue access point where attackers create a fraudulent Wi-Fi network that appears to be a legitimate public network.

##### 2. How Evil Twins Work

- Eavesdropping: Attackers monitor legitimate public Wi-Fi networks and capture SSIDs and encryption settings.
- Creating the Fake Network: The attacker sets up a rogue access point with the same SSID and encryption settings, tricking users into connecting.

##### 3. Risks and Consequences

- Data Interception: Attackers can intercept data transmitted through the evil twin, exposing sensitive information.
- Credential Theft: Users who unknowingly connect to the evil twin may inadvertently provide login credentials to the attacker.

##### 4. Detection and Prevention

- User Awareness: Educate users about the risks of connecting to unsecured public Wi-Fi networks.
- Check SSID Accuracy: Users should verify the SSID of public Wi-Fi networks with authorized personnel.

##### 5. Secure Wi-Fi Practices

- Connect to Known Networks: Only connect to Wi-Fi networks you know and trust.
- Use VPN: When connecting to public Wi-Fi, use a virtual private network (VPN) to encrypt your traffic.

##### 6. HTTPS and Secure Protocols

- Ensure websites use HTTPS to encrypt data transmitted over the network, protecting against potential eavesdropping.

##### 7. Mobile Hotspot Security

- When creating a mobile hotspot, use strong encryption and avoid using common SSIDs to prevent impersonation.

##### 8. Conclusion

- Rogue access points and evil twins pose significant security risks, and users and organizations must remain vigilant to protect their data and privacy.