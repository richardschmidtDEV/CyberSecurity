##### Shoulder Surfing

##### 1. Introduction

- Shoulder surfing is a form of social engineering and information gathering technique in which an individual covertly observes someone else's sensitive or confidential information by looking over their shoulder.
- This technique is commonly used to steal passwords, PINs, credit card numbers, login credentials, or any other valuable information that the victim is entering on a computer, smartphone, or keypad.

##### 2. Motivations and Reasons for Shoulder Surfing

- Identity Theft: The primary motivation behind shoulder surfing is to gain unauthorized access to personal information for identity theft or financial fraud.
- Espionage: Competitors or malicious actors may employ shoulder surfing to gather sensitive business or government-related information.
- Cybercrime: Shoulder surfing is often a precursor to cyber-attacks, enabling attackers to compromise accounts or systems.

##### 3. Common Scenarios for Shoulder Surfing

- ATMs and Payment Terminals: Criminals may observe PIN entries or credit card numbers at ATMs or point-of-sale terminals.
- Public Wi-Fi: Shoulder surfing can occur when people use public Wi-Fi networks and enter login credentials or sensitive data.
- Workplaces: Disgruntled employees or malicious insiders may engage in shoulder surfing to gather sensitive company information.

##### 4. Risks and Dangers

- Identity Theft and Fraud: Shoulder surfing can lead to unauthorized access to personal accounts, leading to identity theft or financial loss.
- Business Espionage: Competitors or adversaries can use the gathered information to gain a competitive advantage.
- Privacy Breach: Shoulder surfing violates an individual's privacy and can lead to significant consequences.

##### 5. Tips for Preventing Shoulder Surfing

- Use Privacy Screens: Privacy screens or screen protectors on electronic devices can limit the viewing angle, making it difficult for shoulder surfers to see the screen.
- Be Aware of Surroundings: Be conscious of people nearby when entering sensitive information and ensure no one is looking over your shoulder.
- Shield PINs and Passwords: When entering passwords or PINs in public, use your hand or body to shield the input from prying eyes.
- Avoid Public Wi-Fi for Sensitive Activities: Refrain from accessing sensitive accounts or providing personal information when connected to public Wi-Fi networks.

##### 6. Shoulder Surfing Awareness for Businesses

- Employee Training: Organizations should educate employees about shoulder surfing risks and best practices for safeguarding sensitive information.
- Physical Security: Ensure that workstations, keypads, and screens are positioned in a way that prevents easy viewing by unauthorized individuals.

##### 7. Conclusion

- Shoulder surfing is a significant threat to information security and personal privacy.
- Implementing preventive measures and promoting awareness can help individuals and businesses protect themselves from shoulder surfing attacks.