##### Cloud Models

##### 1. Infrastructure as a Service (IaaS)

- **Introduction**: IaaS provides virtualized computing resources over the internet, allowing users to rent IT infrastructure on a pay-as-you-go basis.
- **Key Characteristics**:
    - Scalability: Resources can be easily scaled up or down based on demand.
    - Self-Service: Users have control over provisioning and managing the infrastructure.
- **Examples**: Amazon Web Services (AWS) EC2, Microsoft Azure Virtual Machines.

##### 2. Platform as a Service (PaaS)

- **Introduction**: PaaS offers a complete development and deployment environment in the cloud, enabling developers to build, deploy, and manage applications without worrying about underlying infrastructure.
- **Key Characteristics**:
    - Development Tools: PaaS platforms include programming languages, development frameworks, and tools.
    - Automatic Scaling: PaaS platforms can automatically scale applications based on demand.
- **Examples**: Google App Engine, Microsoft Azure App Service.

##### 3. Software as a Service (SaaS)

- **Introduction**: SaaS delivers software applications over the internet on a subscription basis, accessible via a web browser without needing local installation or maintenance.
- **Key Characteristics**:
    - Accessibility: Users can access the software from any device with an internet connection.
    - Maintenance: The service provider is responsible for software maintenance and updates.
- **Examples**: Google Workspace (formerly G Suite), Microsoft Office 365, Salesforce.

##### Deployment Models

##### 1. Public Cloud

- **Introduction**: The cloud infrastructure is owned and operated by a cloud service provider, accessible to the general public, and resources are shared among multiple organizations.
- **Key Characteristics**:
    - Accessibility: Open to the general public over the internet.
    - Multi-Tenancy: Resources are shared among different organizations or tenants.
- **Example**: Amazon Web Services (AWS), Microsoft Azure.

##### 2. Private Cloud

- **Introduction**: A private cloud offers dedicated infrastructure solely for a single organization, providing greater control and security.
- **Key Characteristics**:
    - Ownership: The cloud infrastructure is exclusively for one organization.
    - Control: The organization has full control over resources and configurations.
- **Example**: Private clouds deployed on-premises or through a dedicated service provider.

##### 3. Hybrid Cloud

- **Introduction**: A hybrid cloud combines elements of public and private clouds, allowing data and applications to move between them.
- **Key Characteristics**:
    - Flexibility: Organizations can take advantage of both public cloud scalability and private cloud security.
    - Data Portability: Data and applications can be moved between different cloud environments.
- **Example**: Organizations using a mix of public cloud services and private cloud resources.

##### 4. Community Cloud

- **Introduction**: A community cloud is a shared infrastructure deployed for a specific community of users with shared concerns or interests.
- **Key Characteristics**:
    - Specific Community: Shared among users from similar industries or organizations.
    - Shared Concerns: The cloud meets the needs of the community's specific requirements.
- **Example**: Cloud infrastructure shared among multiple healthcare providers or government agencies.