##### MAC Flooding

##### 1. Introduction

- MAC flooding is a network attack that exploits the way switches handle MAC address table updates, causing a denial of service.

##### 2. How MAC Flooding Works

- Switch MAC Address Tables: Network switches use MAC address tables to map MAC addresses to specific switch ports.
- Flooded MAC Addresses: Attackers flood the switch with a large number of fake MAC addresses, overwhelming the MAC address table.
- Fail-Open Behavior: When the MAC address table becomes full, the switch falls back to a fail-open behavior, treating all traffic as broadcast traffic.

##### 3. Purpose and Impact

- Denial of Service: MAC flooding causes a DoS condition as legitimate traffic is treated as broadcast traffic, leading to network congestion.
- Traffic Sniffing: Attackers can use MAC flooding to capture sensitive information transmitted over the network.

##### 4. Detecting and Preventing MAC Flooding

- Port Security: Configure port security on switches to limit the number of MAC addresses allowed on a specific port.
- MAC Aging: Set a shorter MAC address aging time to remove inactive MAC addresses from the table quickly.
- Network Monitoring: Implement network monitoring tools to detect unusual spikes in MAC address table updates.

##### MAC Cloning

##### 1. Introduction

- MAC cloning, also known as MAC spoofing, is a technique where an attacker impersonates another device by changing their MAC address.

##### 2. How MAC Cloning Works

- Manipulating MAC Address: Attackers modify their network interface's MAC address to match the MAC address of an authorized device.
- Bypassing MAC Filtering: MAC cloning allows attackers to bypass MAC address filtering, a security measure used to restrict network access to authorized devices.

##### 3. Purpose and Impact

- Unauthorized Access: Attackers use MAC cloning to impersonate authorized devices and gain access to a secured network.
- Evasion of Controls: MAC cloning allows attackers to evade security mechanisms that rely solely on MAC address-based authentication.

##### 4. Detecting and Preventing MAC Cloning

- Port Security: Implement port security to limit the number of MAC addresses allowed on specific switch ports.
- Network Access Control: Use additional authentication methods like 802.1X to supplement MAC address-based access control.
- Network Monitoring: Monitor the network for duplicate MAC addresses or unusual MAC address changes.

##### 5. Legal Implications

- MAC cloning can be both an attack technique and a legitimate troubleshooting practice. However, using MAC cloning for malicious purposes may be illegal.

##### 6. Conclusion

- MAC flooding and MAC cloning are network attacks that exploit weaknesses in the MAC address handling of switches and network devices.
- Implementing proper security measures, such as port security and network monitoring, is essential to defend against these attacks.