
<u><font color="#e36c09">Redirection a legit website to a bogus site</font></u>
- Poisoned DNS server or client vulnerabilities



<u><font color="#e36c09">Combine pharming with phishing</font></u>
- Pharming - Harvest large groups of people
- Phishing - Collect access credentials


<div></div>
<u><font color="#e36c09">Difficult for anti-malware software to stop</font></u>
- Everything appears legitimate to the user

<u><font color="#e36c09">Vishing (Voice Phishing) is done over the phone or voicemail</font></u>
- Caller ID spoofing is common
- Fake security checks or bank updates


<u><font color="#e36c09">Smishing (SMS Phishing) is done by text message</font></u>
- Spoofing is a problem as well here
- Forwards links or asks for personal information

<u><font color="#e36c09">Reconaissance</font></u>
- Gather information about the victim


<u><font color="#e36c09">Background information</font></u>
- Lead generation sites
- LinkedIn, Twitter, Facebook
- Corporate website


<u><font color="#e36c09">Attacker builds a believable pretext</font></u>
- where you work
- where you bank 
- recent financial transaction
- family and friends


<u><font color="#e36c09">Spear phishing</font></u>
Targeted phishing with inside information
- makes attack more believable
Spear phishing the CEO is "whaling"
- targeted phishing with the possibility of a large catch
- the CFO is a common target
These executives have direct access to the corporate bank account 
- the attacker would love to have those credentials