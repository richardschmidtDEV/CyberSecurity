##### Bluejacking

##### 1. Introduction

- Bluejacking is a wireless attack that involves sending unsolicited messages or business cards to nearby Bluetooth-enabled devices.

##### 2. How Bluejacking Works

- Proximity-Based Attack: Bluejacking requires the attacker to be in close physical proximity to the target device (usually within 10 meters).
- Sending Unsolicited Messages: Attackers use the Bluetooth feature of their device to discover nearby Bluetooth devices and send messages without pairing.

##### 3. Purpose and Impact

- Harmless Prank: Bluejacking is usually considered a harmless prank to surprise or confuse the target by receiving an unexpected message.
- No Data Theft: Bluejacking does not involve data theft or compromise of sensitive information.

##### 4. Preventing Bluejacking

- Turn Off Device Visibility: By setting Bluetooth devices to "non-discoverable" mode, users can prevent receiving unsolicited messages.
- Disable Bluetooth: Turning off Bluetooth when not in use reduces the risk of being targeted.

##### Bluesnarfing

##### 1. Introduction

- Bluesnarfing is a more serious Bluetooth attack that targets unauthorized access to a device's data, such as contacts, emails, or files.

##### 2. How Bluesnarfing Works

- Exploiting Vulnerable Devices: Bluesnarfing exploits security vulnerabilities in older Bluetooth implementations.
- Unauthorized Access: Attackers use special software to gain access to a device's data without the user's knowledge or consent.

##### 3. Risks and Consequences

- Data Theft: Bluesnarfing can lead to unauthorized access to sensitive data, including personal contacts, messages, and files.
- Privacy Invasion: Users may not be aware that their data is compromised, leading to privacy concerns.

##### 4. Preventing Bluesnarfing

- Keep Software Up-to-Date: Ensure that devices have the latest firmware and security patches to address potential vulnerabilities.
- Use Strong Authentication: Enable PIN or password protection for Bluetooth connections to prevent unauthorized access.
- Disable Unused Services: Turn off unnecessary Bluetooth services to minimize attack surface.

##### 5. Legal Implications

- Bluesnarfing is considered a criminal act, as it involves unauthorized access to personal data.

##### 6. Conclusion

- Bluejacking and bluesnarfing are both Bluetooth-related attacks, but they have different intents and consequences.
- Users should be cautious about Bluetooth usage and follow best practices to protect their devices and data.