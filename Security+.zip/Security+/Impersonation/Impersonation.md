

<u><font color="#00b0f0">The Pretext</font></u>

<u><font color="#e36c09">Before the attack, the trap is set</font></u>
- There's and actor and a story
- - "Hello sir, .my name is Wendy and i'm from Microsoft Windows.
This is an urgent check up call for your computer as we have found several problems with it"
- Voice mail: "This is an enforcement action executed by the US Treasury intending your serious attention"
- "Congratulations on your excellent payment history! You now qualify for 0% interest rates on all of your credit card accounts"

<u><font color="#00b0f0">Impersonation</font></u>

<u><font color="#e36c09">Attackers pretend to be someone they aren't</font></u>
- Halloween for the fraudsters

<div></div>
<u><font color="#e36c09">Use some of the details from reconnaissance</font></u>
- You can trust me, i'm with your helpdesk

<u><font color="#e36c09">Attack the victim as someone higher in rank</font></u>
- Office of the Vice President for Scamming 


<u><font color="#e36c09">Throw tons of technical details around</font></u>
- "Catastrophic feedback due to the depolarization
of the differential magnetometer"

<u><font color="#e36c09">Be a buddy</font></u>
- "How about those Cubs ?"

<u><font color="#00b0f0">Eliciting Information</font></u>
<u></u>
<u><font color="#e36c09">Extracting information from the victim</font></u>
- The victim doesn't even realize that this is happening
- Hacking the human


<u><font color="#e36c09">Often seen with vishing</font></u>
- Can be easier to get this 
information over the phone  

<u><font color="#e36c09">These are well documented psychological techniques</font></u>
- They can't just ask "what's your pw ?" 


<u><font color="#00b0f0">Identity Fraud</font></u>

<u><font color="#de7802">Your identity can be used by others</font></u>
- Keep your personal information safe

<u><font color="#de7802">Credit card fraud</font></u>
Open an account in your name, or use your credit card information

<u><font color="#de7802">Bank fraud</font></u>
- Attacker gains access to your account or opens a new account

<u><font color="#de7802">Loan fraud</font></u>
- Your information is used for a loan or lease

<u><font color="#de7802">Government benefits fraud</font></u>
- Attacker obtains benefits on your behalf